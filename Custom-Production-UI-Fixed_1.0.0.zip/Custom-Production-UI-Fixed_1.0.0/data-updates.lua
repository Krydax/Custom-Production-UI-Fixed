data.raw["utility-constants"]["default"].select_group_row_count = 10
data.raw["utility-constants"]["default"].select_slot_row_count = 16
data.raw["utility-constants"]["default"].inventory_width = 12
data.raw["gui-style"]["default"].inventory_scroll_pane.minimal_width = data.raw["utility-constants"]["default"].inventory_width * 40 + 12